//
//  DateTimeHelper.h
//  LazzyBee
//
//  Created by HuKhong on 4/19/15.
//  Copyright (c) 2015 HuKhong. All rights reserved.
//

#ifndef LazzyBee_DateTimeHelper_h
#define LazzyBee_DateTimeHelper_h
#import <Foundation/Foundation.h>

@interface DateTimeHelper : NSObject

// a singleton:
+ (DateTimeHelper*) sharedDateTimeHelper;


- (NSString *)getCurrentDatetimeWithFormat:(NSString *)formatString;
- (NSString *)getNextDatetimeWithFormat:(NSString *)formatString;
- (NSString *)dateStringFromDate:(NSDate *)date withFormat:(NSString *)formatString;
- (NSString *)timeStringFromDate:(NSDate *)date;
- (NSString *)stringDateFromString:(NSString *)dateStr;
- (NSDate *)dateFromString:(NSString *)dateStr;
- (NSTimeInterval)getCurrentDatetimeInMinisec;
- (NSTimeInterval)getBeginOfDayInMinisec;
- (NSTimeInterval)getCurrentDatetimeInSec;
- (NSTimeInterval)getBeginOfDayInSec;
- (NSString *)getDayOfWeek:(NSDate *)date;
- (NSString *)convertDateOfWeekToVN:(NSString *)dateOfWeek;

@end

#endif
