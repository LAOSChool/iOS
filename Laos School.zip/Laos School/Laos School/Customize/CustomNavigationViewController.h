//
//  CustomNavigationViewController.h
//  Laos School
//
//  Created by HuKhong on 2/22/16.
//  Copyright © 2016 com.born2go.laosschool. All rights reserved.
//

#ifndef CustomNavigationViewController_h
#define CustomNavigationViewController_h
#import <UIKit/UIKit.h>

@interface CustomNavigationViewController : UINavigationController
{
    
}

@end

#endif /* CustomNavigationViewController_h */
