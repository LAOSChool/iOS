//
//  CustomNavigationViewController.m
//  Laos School
//
//  Created by HuKhong on 2/22/16.
//  Copyright © 2016 com.born2go.laosschool. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CustomNavigationViewController.h"

@implementation CustomNavigationViewController
{

}

- (instancetype)initWithRootViewController:(UIViewController *)rootViewController {
    self = [super initWithRootViewController:rootViewController];
    if (self) {
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 70000
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
        {
            [self.navigationBar setTranslucent:NO];
        }
#endif
        [self.navigationBar setBarTintColor:[UIColor whiteColor]];
        self.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
        [self.navigationBar setTintColor:[UIColor whiteColor]];
    }
    return self;
}

@end